/**
 * @file Gestion complète de bibliothèque avec système de rôles
 * @version 7.1
 */  
const DB_NAME = 'LibraTechDB';
const DB_VERSION = 19;
let db;
let currentUser = null;
let scanner = null;
let chartInstance = null;
let currentBooks = [];

class LibraTech {
    static DB_NAME = 'LibraTechDB_Django';
    static DB_VERSION = 1;
    static db = null;

    static async init() {
        return new Promise((resolve, reject) => {
            // Fermer la connexion existante si nécessaire
            if (this.db) this.db.close();

            const request = indexedDB.open(this.DB_NAME, this.DB_VERSION);

            request.onerror = (e) => {
                console.error("Erreur DB:", e.target.error);
                reject(e.target.error);
            };

            request.onsuccess = (e) => {
                this.db = e.target.result;
                
                // Vérification des objectStores
                const requiredStores = ['livres', 'utilisateurs', 'reservations'];
                const missingStores = requiredStores.filter(store => 
                    !this.db.objectStoreNames.contains(store)
                );

                if (missingStores.length > 0) {
                    console.log("Stores manquants, recréation de la DB...");
                    this.db.close();
                    indexedDB.deleteDatabase(this.DB_NAME);
                    this.init().then(resolve).catch(reject);
                    return;
                }

                console.log("DB initialisée avec succès");
                resolve();
            };

            request.onupgradeneeded = (e) => {
                const db = e.target.result;
                console.log("Mise à jour/nouvelle DB nécessaire");

                if (!db.objectStoreNames.contains('livres')) {
                    db.createObjectStore('livres', { 
                        keyPath: 'id',
                        autoIncrement: true 
                    });
                }

                if (!db.objectStoreNames.contains('utilisateurs')) {
                    db.createObjectStore('utilisateurs', { 
                        keyPath: 'id'
                    });
                }

                if (!db.objectStoreNames.contains('reservations')) {
                    db.createObjectStore('reservations', { 
                        keyPath: 'id',
                        autoIncrement: true 
                    });
                }
            };
        });
    }

    // ... autres méthodes ...
    static init() {
        
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);

            request.onupgradeneeded = (e) => {
                db = e.target.result;
 
                if (!db.objectStoreNames.contains('livres')) {
                    const livresStore = db.createObjectStore('livres', {
                        keyPath: 'id',
                        autoIncrement: true
                    });
                    livresStore.createIndex('titre', 'titre', { unique: false });
                    livresStore.createIndex('isbn', 'isbn', { unique: true });
                    livresStore.createIndex('statut', 'statut', { unique: false });
                }

                if (!db.objectStoreNames.contains('utilisateurs')) {
                    const usersStore = db.createObjectStore('utilisateurs', { keyPath: 'id' });
                    usersStore.createIndex('username', 'username', { unique: true });
                    usersStore.createIndex('role', 'role', { unique: false });
                }

                if (!db.objectStoreNames.contains('reservations')) {
                    const resaStore = db.createObjectStore('reservations', {
                        keyPath: 'id',
                        autoIncrement: true
                    });
                    resaStore.createIndex('livreId', 'livreId');
                    resaStore.createIndex('userId', 'userId');
                    resaStore.createIndex('statut', 'statut');
                    resaStore.createIndex('dateEmprunt', 'dateEmprunt');
                    resaStore.createIndex('dateRetour', 'dateRetour');
                }
            };

            request.onsuccess = async (e) => {
                db = e.target.result;
                await this.initializeDefaultAdmin();
                resolve();
            };

            request.onerror = (e) => reject(`Erreur DB: ${e.target.error}`);
        });
    }

    static async initializeDefaultAdmin() {
        const tx = db.transaction('utilisateurs', 'readwrite');
        const store = tx.objectStore('utilisateurs');
        
        // Vérifier et ajouter l'admin
        const adminRequest = store.get(1);
        adminRequest.onsuccess = () => {
            if (!adminRequest.result) {
                store.add({
                    id: 1,
                    username: 'admin',
                    password: 'admin123',
                    role: 'admin',
                    email: 'admin@libraTech.com',
                    dateCreation: new Date().toISOString()
                });
            }
        };
    
        // Ajouter le bibliothécaire par défaut
        const biblioRequest = store.get(2);
        biblioRequest.onsuccess = () => {
            if (!biblioRequest.result) {
                store.add({
                    id: 2,
                    username: 'biblio',
                    password: 'biblio123',
                    role: 'bibliothecaire',
                    email: 'biblio@libraTech.com',
                    dateCreation: new Date().toISOString()
                });
            }
        };
    }
    

    static async login(username, password, role) {
        return new Promise((resolve, reject) => {
            const tx = db.transaction('utilisateurs', 'readonly');
            const store = tx.objectStore('utilisateurs');
            const index = store.index('username');

            const request = index.get(username);
            request.onsuccess = (e) => {
                const user = e.target.result;
                if (user?.password === password && user?.role === role) {
                    resolve(user);
                } else {
                    reject('Identifiants incorrects');
                }
            };
            request.onerror = () => reject('Erreur de recherche');
            
        });
        
       document.getElementById('login-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    const role = document.getElementById('userType').value;

    try {
        const user = await LibraTech.login(username, password, role);
        
        sessionStorage.setItem('currentUser', JSON.stringify(user));
        
        if (user.role === 'admin') {
            window.location.href = 'admin.html';
        } else if (user.role === 'bibliothecaire') {
            window.location.href = 'bibliothecaire.html';
        } else {
            UI.showNotification('Rôle non reconnu', 'danger');
        }
        
    } catch (error) {
        UI.showNotification(error.message || 'Erreur de connexion', 'danger');
    }
});
        
    }

    static async getLivres() {
        return new Promise((resolve) => {
            const tx = db.transaction('livres', 'readonly');
            const request = tx.objectStore('livres').getAll();
            request.onsuccess = () => resolve(request.result);
        });
    }

    static async getLivreById(id) {
        return new Promise((resolve) => {
            const tx = db.transaction('livres', 'readonly');
            const request = tx.objectStore('livres').get(id);
            request.onsuccess = () => resolve(request.result);
        });
    }

    static async addLivre(livre) {
        return new Promise((resolve, reject) => {
            const tx = db.transaction('livres', 'readwrite');
            const request = tx.objectStore('livres').add(livre);
            request.onsuccess = () => resolve(request.result);
            request.onerror = (e) => reject(e.target.error);
        });
    }

    static async updateLivre(livre) {
        return new Promise((resolve, reject) => {
            const tx = db.transaction('livres', 'readwrite');
            const request = tx.objectStore('livres').put(livre);
            request.onsuccess = () => resolve();
            request.onerror = (e) => reject(e.target.error);
        });
    }

    static async deleteLivre(id) {
        return new Promise((resolve, reject) => {
            const tx = db.transaction('livres', 'readwrite');
            const request = tx.objectStore('livres').delete(id);
            request.onsuccess = () => resolve();
            request.onerror = (e) => reject(e.target.error);
        });
    }

    static async searchBooks(query) {
        const livres = await this.getLivres();
        const normalizedQuery = query.toLowerCase().trim();
        
        return livres.filter(livre => {
            // Vérifie si au moins un champ commence par la recherche
            return [
                livre.titre?.toLowerCase(),
                livre.auteur?.toLowerCase(),
                livre.isbn?.toLowerCase()
            ].some(field => field?.startsWith(normalizedQuery));
        });
        // Alternative mixant "commence par" ET "contient"
field?.startsWith(normalizedQuery) || field?.includes(normalizedQuery)
    }

    static async getBooksByStatus(status) {
        const livres = await this.getLivres();
        return livres.filter(livre => livre.statut.toLowerCase() === status.toLowerCase());
    }

    static async getUtilisateurs() {
        return new Promise((resolve) => {
            const tx = db.transaction('utilisateurs', 'readonly');
            const request = tx.objectStore('utilisateurs').getAll();
            request.onsuccess = () => resolve(request.result);
        });
    }

    static async addUser(user) {
        return new Promise((resolve, reject) => {
            const tx = db.transaction('utilisateurs', 'readwrite');
            const request = tx.objectStore('utilisateurs').add(user);
            request.onsuccess = () => resolve(request.result);
            request.onerror = (e) => reject(e.target.error);
        });
    }

    static async updateUser(user) {
        return new Promise((resolve, reject) => {
            const tx = db.transaction('utilisateurs', 'readwrite');
            const request = tx.objectStore('utilisateurs').put(user);
            request.onsuccess = () => resolve();
            request.onerror = (e) => reject(e.target.error);
        });
    }

    static async deleteUser(userId) {
        return new Promise((resolve, reject) => {
            const tx = db.transaction('utilisateurs', 'readwrite');
            const request = tx.objectStore('utilisateurs').delete(userId);
            request.onsuccess = () => resolve();
            request.onerror = (e) => reject(e.target.error);
        });
    }

    static async getReservations() {
        return new Promise((resolve) => {
            const tx = db.transaction('reservations', 'readonly');
            const request = tx.objectStore('reservations').getAll();
            request.onsuccess = () => resolve(request.result);
        });
    }

    static async addReservation(reservation) {
        return new Promise((resolve, reject) => {
            const tx = db.transaction('reservations', 'readwrite');
            const request = tx.objectStore('reservations').add(reservation);
            request.onsuccess = () => resolve(request.result);
            request.onerror = (e) => reject(e.target.error);
        });
    }

    static async updateReservation(reservation) {
        return new Promise((resolve, reject) => {
            const tx = db.transaction('reservations', 'readwrite');
            const request = tx.objectStore('reservations').put(reservation);
            request.onsuccess = () => resolve();
            request.onerror = (e) => reject(e.target.error);
        });
    }

    static async deleteReservation(id) {
        return new Promise((resolve, reject) => {
            const tx = db.transaction('reservations', 'readwrite');
            const request = tx.objectStore('reservations').delete(id);
            request.onsuccess = () => resolve();
            request.onerror = (e) => reject(e.target.error);
        });
    }

    static async getReservationsByUser(userId) {
        const reservations = await this.getReservations();
        return reservations.filter(r => r.userId === userId);
    }

    static async getReservationsByBook(bookId) {
        const reservations = await this.getReservations();
        return reservations.filter(r => r.livreId === bookId);
    }

    static async getActiveReservation(bookId) {
        const reservations = await this.getReservationsByBook(bookId);
        return reservations.find(r => r.statut === 'Emprunté' || r.statut === 'Réservé');
    }

    static async emprunterLivre(id) {
        return new Promise(async (resolve, reject) => {
            try {
                const tx = db.transaction(['livres', 'reservations'], 'readwrite');
                const livresStore = tx.objectStore('livres');
                const reservationsStore = tx.objectStore('reservations');

                const livre = await this.getLivreById(id);
                if (!livre) {
                    reject('Livre non trouvé');
                    return;
                }

                if (livre.statut !== 'Disponible') {
                    reject('Livre non disponible');
                    return;
                }

                livre.statut = 'Emprunté';
                livre.dateEmprunt = new Date().toISOString();
                livre.dateRetour = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString();

                await this.updateLivre(livre);
                
                await this.addReservation({
                    livreId: id,
                    userId: currentUser.id,
                    dateEmprunt: livre.dateEmprunt,
                    dateRetour: livre.dateRetour,
                    statut: 'Emprunté'
                });

                resolve();
            } catch (error) {
                reject(error);
            }
        });
    }

    static async retournerLivre(id) {
        return new Promise(async (resolve, reject) => {
            try {
                const tx = db.transaction(['livres', 'reservations'], 'readwrite');
                const livresStore = tx.objectStore('livres');
                const reservationsStore = tx.objectStore('reservations');

                const livre = await this.getLivreById(id);
                if (!livre) {
                    reject('Livre non trouvé');
                    return;
                }

                if (livre.statut !== 'Emprunté') {
                    reject('Livre non emprunté');
                    return;
                }

                livre.statut = 'Disponible';
                livre.dateEmprunt = null;
                livre.dateRetour = null;

                await this.updateLivre(livre);
                
                const activeReservation = await this.getActiveReservation(id);
                if (activeReservation) {
                    activeReservation.statut = 'Retourné';
                    activeReservation.dateRetour = new Date().toISOString();
                    await this.updateReservation(activeReservation);
                }

                resolve();
            } catch (error) {
                reject(error);
            }
        });
    }

    static async reserverLivre(id) {
        return new Promise(async (resolve, reject) => {
            try {
                const tx = db.transaction(['livres', 'reservations'], 'readwrite');
                const livresStore = tx.objectStore('livres');
                const reservationsStore = tx.objectStore('reservations');

                const livre = await this.getLivreById(id);
                if (!livre) {
                    reject('Livre non trouvé');
                    return;
                }

                if (livre.statut !== 'Disponible') {
                    reject('Livre non disponible');
                    return;
                }

                livre.statut = 'Réservé';
                livre.dateReservation = new Date().toISOString();

                await this.updateLivre(livre);
                
                await this.addReservation({
                    livreId: id,
                    userId: currentUser.id,
                    dateReservation: livre.dateReservation,
                    statut: 'Réservé'
                });

                resolve();
            } catch (error) {
                reject(error);
            }
        });
    }

    static async annulerReservation(id) {
        return new Promise(async (resolve, reject) => {
            try {
                const tx = db.transaction(['livres', 'reservations'], 'readwrite');
                const livresStore = tx.objectStore('livres');
                const reservationsStore = tx.objectStore('reservations');

                const livre = await this.getLivreById(id);
                if (!livre) {
                    reject('Livre non trouvé');
                    return;
                }

                if (livre.statut !== 'Réservé') {
                    reject('Livre non réservé');
                    return;
                }

                livre.statut = 'Disponible';
                livre.dateReservation = null;

                await this.updateLivre(livre);
                
                const activeReservation = await this.getActiveReservation(id);
                if (activeReservation) {
                    activeReservation.statut = 'Annulé';
                    await this.updateReservation(activeReservation);
                }

                resolve();
            } catch (error) {
                reject(error);
            }
        });
    }

    static showBookDetails(livre) {
        // Ajouter cette ligne au début de showBookDetails
document.querySelectorAll('.modal').forEach(m => m.style.display = 'none');
        const modal = document.getElementById('book-details-modal');
        if (!modal) return;

        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Détails du Livre</h3>
                    <span class="close">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="book-details-container">
                        <div class="book-details-cover">
                            <img src="${livre.couverture || 'https://via.placeholder.com/300x450'}" 
                                alt="${livre.titre}">
                            <div class="book-status-badge large status-${livre.statut.toLowerCase()}">
                                ${livre.statut}
                            </div>
                        </div>
                        <div class="book-details-info">
                            <h2>${livre.titre}</h2>
                            <p><strong>Auteur:</strong> ${livre.auteur}</p>
                            <p><strong>ISBN:</strong> ${livre.isbn}</p>
                            <p><strong>Genre:</strong> ${livre.genre || 'Non spécifié'}</p>
                            ${livre.statut === 'Emprunté' ? `
                                <p><strong>Emprunté le:</strong> ${new Date(livre.dateEmprunt).toLocaleDateString()}</p>
                                <p><strong>Retour prévu:</strong> ${new Date(livre.dateRetour).toLocaleDateString()}</p>
                            ` : ''}
                            ${livre.statut === 'Réservé' ? `
                                <p><strong>Réservé le:</strong> ${new Date(livre.dateReservation).toLocaleDateString()}</p>
                            ` : ''}
                            <p><strong>Description:</strong></p>
                            <div class="book-description">${livre.description || 'Aucune description disponible'}</div>
                            
                            <div class="qr-code-section">
                                <button class="btn primary" id="show-qr-btn">
                                    <i class="fas fa-qrcode"></i> Afficher QR Code
                                </button>
                                <div id="qr-code-container" class="hidden">
                                    <div id="qr-code-image"></div>
                                    <p class="qr-caption">Scannez ce code pour accéder aux détails du livre</p>
                                </div>
                            </div>

                            <div class="book-actions">
                                ${livre.statut === 'Disponible' ? `
                                    <button class="btn success" data-action="borrow" data-id="${livre.id}">
                                        <i class="fas fa-book"></i> Emprunter
                                    </button>
                                    <button class="btn primary" data-action="reserve" data-id="${livre.id}">
                                        <i class="fas fa-bookmark"></i> Réserver
                                    </button>
                                ` : ''}
                                ${livre.statut === 'Emprunté' ? `
                                    <button class="btn danger" data-action="return" data-id="${livre.id}">
                                        <i class="fas fa-undo"></i> Retourner
                                    </button>
                                ` : ''}
                                ${livre.statut === 'Réservé' ? `
                                    <button class="btn warning" data-action="cancel-reserve" data-id="${livre.id}">
                                        <i class="fas fa-times"></i> Annuler réservation
                                    </button>
                                ` : ''}
                                ${['admin', 'bibliothecaire'].includes(currentUser?.role) ? `
                                    <button class="btn warning" data-action="edit" data-id="${livre.id}">
                                        <i class="fas fa-edit"></i> Modifier
                                    </button>
                                    <button class="btn danger" data-action="delete" data-id="${livre.id}">
                                        <i class="fas fa-trash"></i> Supprimer
                                    </button>
                                ` : ''}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        const showQrBtn = document.getElementById('show-qr-btn');
        const qrContainer = document.getElementById('qr-code-container');
        
        showQrBtn?.addEventListener('click', () => {
            qrContainer.classList.toggle('hidden');
            if (!qrContainer.classList.contains('hidden')) {
                this.generateQRCode(livre);
            }
        });

        modal.style.display = 'flex';
        
        document.querySelector('.close')?.addEventListener('click', () => {
            modal.style.display = 'none';
        });
        
    }
    // Dans la classe LibraTech
// Ajoutez cette méthode dans la classe LibraTech
// Méthode de secours avec vérification

static generateQRCodeForBook(livre) {
    const qrContainer = document.getElementById(`qrcode-${livre.id}`);
     
    if (!qrContainer) {
        console.error('Container QR code introuvable pour le livre:', livre.id);
        return;
    }

    try {
        new QRCode(qrContainer, {
            text: `LIVRE:${livre.id}|${livre.isbn}`,
            width: 80,
            height: 80,
            colorDark: "#2A2F4F",
            colorLight: "#ffffff",
            correctLevel: QRCode.CorrectLevel.H
        });
    } catch (error) {
        console.error('Erreur génération QR code:', error);
        qrContainer.innerHTML = 'QR indisponible';
    }
}

// Modifiez la fonction renderBooks
static renderBooks(livres) {
    const grid = document.getElementById('books-grid');
    if (!grid) return;

    grid.innerHTML = livres.map(livre => `
        <div class="book-card" data-id="${livre.id}">
            <div class="book-status-badge status-${livre.statut.toLowerCase()}">
                ${livre.statut}
            </div>
            <div class="book-qrcode" id="qrcode-${livre.id}"></div>
            <img src="${livre.couverture || 'placeholder.jpg'}" 
                 class="book-cover" 
                 alt="${livre.titre}">
            <div class="book-info">
                <div class="book-title">${livre.titre}</div>
                <div class="book-author">${livre.auteur}</div>
            </div>
        </div>
    `).join('');

    // Génération des QR codes après le rendu
    livres.forEach(livre => {
        this.generateQRCodeForBook(livre);
    });
}
// Modifier la fonction renderBooks
static renderBooks(livres) {
    const grid = document.getElementById('books-grid');
    if (!grid || !Array.isArray(livres)) return;

    currentBooks = livres;
    
    // Générer le HTML
    grid.innerHTML = livres.map(livre => `
        <div class="book-card" data-id="${livre.id}">
            <div class="book-status-badge status-${livre.statut.toLowerCase()}">
                ${livre.statut}
            </div>
            <div class="book-qrcode" id="qrcode-${livre.id}"></div>
            <img src="${livre.couverture || 'https://via.placeholder.com/200x300'}" 
                 class="book-cover" 
                 alt="${livre.titre}">
            <div class="book-info">
                <div class="book-title">${livre.titre}</div>
                <div class="book-author">${livre.auteur}</div>
                ${livre.statut === 'Emprunté' ? `
                    <div class="book-due-date">
                        <i class="fas fa-calendar-alt"></i>
                        Retour: ${new Date(livre.dateRetour).toLocaleDateString()}
                    </div>
                ` : ''}
            </div>
        </div>
    `).join('');

    // Générer les QR codes après un léger délai
    setTimeout(() => {
        livres.forEach(livre => this.generateBookQRCode(livre));
    }, 100);
}

    static showReservations(reservations) {
        const modal = document.getElementById('reservations-modal');
        if (!modal) return;

        modal.innerHTML = `
            <div class="modal-content extra-large">
                <div class="modal-header">
                    <h3><i class="fas fa-history"></i> Historique des Réservations</h3>
                    <span class="close">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="reservations-controls">
                        <div class="search-box">
                            <input type="text" id="reservation-search" placeholder="Rechercher dans l'historique...">
                            <i class="fas fa-search"></i>
                        </div>
                        <button class="btn primary" id="export-reservations">
                            <i class="fas fa-file-export"></i> Exporter
                        </button>
                    </div>
                    <div class="table-container">
                        <table class="reservations-table">
                            <thead>
                                <tr>
                                    <th>Livre</th>
                                    <th>Utilisateur</th>
                                    <th>Date Emprunt</th>
                                    <th>Date Retour</th>
                                    <th>Statut</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${reservations.map(res => `
                                    <tr>
                                        <td><strong>${res.livreTitre || 'N/A'}</strong><br>
                                            <small>${res.livreAuteur || ''}</small></td>
                                        <td>${res.userName || 'N/A'}<br>
                                            <small>${res.userEmail || ''}</small></td>
                                        <td>${res.dateEmprunt ? new Date(res.dateEmprunt).toLocaleDateString('fr-FR', { 
                                            day: '2-digit', 
                                            month: '2-digit', 
                                            year: 'numeric',
                                            hour: '2-digit',
                                            minute: '2-digit'
                                        }) : '-'}</td>
                                        <td>${res.dateRetour ? new Date(res.dateRetour).toLocaleDateString('fr-FR', { 
                                            day: '2-digit', 
                                            month: '2-digit', 
                                            year: 'numeric',
                                            hour: '2-digit',
                                            minute: '2-digit'
                                        }) : '-'}</td>
                                        <td>
                                            <span class="status-badge ${res.statut.toLowerCase()}">
                                                ${res.statut}
                                            </span>
                                        </td>
                                        <td>
                                            <button class="btn small" data-action="view-book" data-id="${res.livreId}">
                                                <i class="fas fa-book"></i>
                                            </button>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                    <div class="reservations-summary">
                        <div class="summary-card">
                            <h4>Total Réservations</h4>
                            <p>${reservations.length}</p>
                        </div>
                        <div class="summary-card">
                            <h4>En cours</h4>
                            <p>${reservations.filter(r => r.statut === 'Emprunté').length}</p>
                        </div>
                        <div class="summary-card">
                            <h4>En retard</h4>
                            <p>${reservations.filter(r => {
                                if (r.statut === 'Emprunté' && r.dateRetour) {
                                    return new Date(r.dateRetour) < new Date();
                                }
                                return false;
                            }).length}</p>
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.getElementById('reservation-search').addEventListener('input', (e) => {
            const searchTerm = e.target.value.toLowerCase();
            const rows = modal.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });

        modal.style.display = 'flex';
        
        document.querySelector('.close')?.addEventListener('click', () => {
            modal.style.display = 'none';
        });
    }
}

class UI {
    static renderBooks(livres) {
        const grid = document.getElementById('books-grid');
        if (!grid || !Array.isArray(livres)) return;
    
        currentBooks = livres;
        grid.innerHTML = livres.map(livre => `
            <div class="book-card" data-id="${livre.id}">
                <div class="book-status-badge status-${livre.statut.toLowerCase()}">
                    ${livre.statut}
                </div>
                <div class="book-qrcode" id="qrcode-${livre.id}"></div>
                <img src="${livre.couverture || 'https://via.placeholder.com/200x300'}" 
                     class="book-cover" 
                     alt="${livre.titre}">
                <div class="book-info">
                    <!-- ... contenu existant ... -->
                </div>
            </div>
        `).join('');
    
        // Génération des QR codes après le rendu
        livres.forEach(livre => {
            new QRCode(document.getElementById(`qrcode-${livre.id}`), {
                text: JSON.stringify({
                    id: livre.id,
                    titre: livre.titre,
                    isbn: livre.isbn
                }),
                width: 80,
                height: 80,
                colorDark: "#2A2F4F",
                colorLight: "#ffffff",
                correctLevel: QRCode.CorrectLevel.H
            });
        });
    }
    static showNotification(message, type = 'success') {
        const notif = document.createElement('div');
        notif.className = `notification ${type}`;
        notif.textContent = message;
        document.body.appendChild(notif);
        setTimeout(() => notif.remove(), 3000);
    }

    static loadRoleMenu(role) {
        const menuItems = {
            admin: ['Statistiques', 'Gestion Utilisateurs', 'Ajouter Livre', 'Historique Reservations'],
            bibliothecaire: ['Scanner', 'Historique', 'Gestion Livres'],
            etudiant: ['Mes Emprunts', 'Recherche Avancée']
        }[role].map(item => `
            <button class="menu-btn" data-action="${item.toLowerCase().replace(' ', '-')}">
                <i class="fas fa-chevron-right"></i> ${item}
            </button>
        `).join('');

        document.getElementById('sidebarMenu').innerHTML = menuItems;
    }

    static toggleAdminFeatures() {
        document.querySelectorAll('.admin-only').forEach(el => {
            el.style.display = currentUser?.role === 'admin' ? 'flex' : 'none';
        });
    }

    static updateStats(livres) {
        if (!Array.isArray(livres)) {
            console.error("Les données des livres ne sont pas un tableau");
            return;
        }

        const stats = {
            disponible: livres.filter(l => l.statut === 'Disponible').length,
            emprunté: livres.filter(l => l.statut === 'Emprunté').length,
            réservé: livres.filter(l => l.statut === 'Réservé').length
        };

        document.getElementById('available-count').textContent = stats.disponible;
        document.getElementById('borrowed-count').textContent = stats.emprunté;
        document.getElementById('reserved-count').textContent = stats.réservé;

        const ctx = document.getElementById('stats-chart')?.getContext('2d');
        if (!ctx) {
            console.error("Canvas des statistiques introuvable");
            return;
        }

        if (chartInstance) {
            chartInstance.destroy();
        }

        chartInstance = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Disponibles', 'Empruntés', 'Réservés'],
                datasets: [{
                    data: [stats.disponible, stats.emprunté, stats.réservé],
                    backgroundColor: ['#38A169', '#E53E3E', '#DD6B20'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            boxWidth: 12,
                            padding: 20
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.raw || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = Math.round((value / total) * 100);
                                return `${label}: ${value} (${percentage}%)`;
                            }
                        }
                    }
                },
                cutout: '65%'
            }
        });
    }

    static renderBooks(livres) {
        const grid = document.getElementById('books-grid');
        if (!grid || !Array.isArray(livres)) return;

        currentBooks = livres;
        grid.innerHTML = livres.map(livre => `
            <div class="book-card" data-id="${livre.id}">
                <div class="book-status-badge status-${livre.statut.toLowerCase()}">
                    ${livre.statut}
                </div>
                <img src="${livre.couverture || 'https://via.placeholder.com/200x300'}" 
                     class="book-cover" 
                     alt="${livre.titre}">
                <div class="book-info">
                    <div class="book-title">${livre.titre}</div>
                    <div class="book-author">${livre.auteur}</div>
                    ${livre.statut === 'Emprunté' ? `
                        <div class="book-due-date">
                            <i class="fas fa-calendar-alt"></i>
                            Retour: ${new Date(livre.dateRetour).toLocaleDateString()}
                        </div>
                    ` : ''}
                    ${livre.statut === 'Réservé' ? `
                        <div class="book-reserved-date">
                            <i class="fas fa-bookmark"></i>
                            Réservé le: ${new Date(livre.dateReservation).toLocaleDateString()}
                        </div>
                    ` : ''}
                </div>
            </div>
        `).join('');
    }

    static renderUsers(users) {
        const modal = document.getElementById('user-management-modal');
        if (!modal) return;

        modal.innerHTML = `
            <div class="modal-content large">
                <div class="modal-header">
                    <h3><i class="fas fa-users-cog"></i> Gestion des Utilisateurs</h3>
                    <span class="close">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="user-controls">
                        <button class="btn primary" id="add-user-btn">
                            <i class="fas fa-user-plus"></i> Ajouter Utilisateur
                        </button>
                        <div class="search-box">
                            <input type="text" id="user-search" placeholder="Rechercher utilisateur...">
                            <i class="fas fa-search"></i>
                        </div>
                    </div>
                    <div class="table-container">
                        <table class="users-table">
                            <thead>
                                <tr>
                                    <th>Nom</th>
                                    <th>Email</th>
                                    <th>Rôle</th>
                                    <th>Date Création</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="users-list">
                                ${users.map(user => `
                                    <tr>
                                        <td>${user.username}</td>
                                        <td>${user.email || 'N/A'}</td>
                                        <td>
                                            <span class="role-badge ${user.role}">
                                                ${user.role}
                                            </span>
                                        </td>
                                        <td>${new Date(user.dateCreation).toLocaleDateString()}</td>
                                        <td class="actions">
                                            <button class="btn warning" data-user-id="${user.id}" data-action="edit">
                                                <i class="fas fa-edit"></i> Modifier
                                            </button>
                                            <button class="btn danger" data-user-id="${user.id}" data-action="delete">
                                                <i class="fas fa-trash"></i> Supprimer
                                            </button>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;

        modal.style.display = 'flex';
        
        document.querySelector('.close')?.addEventListener('click', () => {
            modal.style.display = 'none';
        });
    }

    static showAddBookModal(livre = null) {
        const modal = document.getElementById('book-modal');
        if (!modal) return;

        const isEditMode = livre !== null;
        
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3><i class="fas fa-book-medical"></i> ${isEditMode ? 'Modifier' : 'Ajouter'} un Livre</h3>
                    <span class="close">&times;</span>
                </div>
                <form id="book-form">
                    <div class="form-grid">
                        <div class="input-group">
                            <label for="book-title">Titre*</label>
                            <input type="text" id="book-title" value="${livre?.titre || ''}" required>
                        </div>
                        <div class="input-group">
                            <label for="book-author">Auteur*</label>
                            <input type="text" id="book-author" value="${livre?.auteur || ''}" required>
                        </div>
                        <div class="input-group">
                            <label for="book-isbn">ISBN*</label>
                            <div class="input-with-icon">
                                <input type="text" id="book-isbn" value="${livre?.isbn || ''}" required>
                                <button type="button" class="btn icon" id="scan-isbn-btn">
                                    <i class="fas fa-qrcode"></i>
                                </button>
                            </div>
                        </div>
                        <div class="input-group">
                            <label for="book-genre">Genre</label>
                            <input type="text" id="book-genre" value="${livre?.genre || ''}">
                        </div>
                        <div class="input-group full-width">
                            <label for="book-description">Description</label>
                            <textarea id="book-description" rows="3">${livre?.description || ''}</textarea>
                        </div>
                        <div class="input-group full-width">
                            <label for="book-cover">Couverture</label>
                            <div class="cover-upload">
                                <input type="file" id="book-cover" accept="image/*">
                                <label for="book-cover" class="upload-label">
                                    <i class="fas fa-cloud-upload-alt"></i> Choisir une image
                                </label>
                            </div>
                            <div id="cover-preview" class="cover-preview">
                                ${livre?.couverture ? `<img src="${livre.couverture}" alt="Preview">` : ''}
                            </div>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn danger" id="cancel-book-btn">
                            <i class="fas fa-times"></i> Annuler
                        </button>
                        <button type="submit" class="btn primary">
                            <i class="fas fa-save"></i> ${isEditMode ? 'Mettre à jour' : 'Enregistrer'}
                        </button>
                    </div>
                </form>
            </div>
        `;

        document.getElementById('book-cover')?.addEventListener('change', function(e) {
            const preview = document.getElementById('cover-preview');
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
                }
                reader.readAsDataURL(this.files[0]);
            }
        });

        document.getElementById('cancel-book-btn')?.addEventListener('click', () => {
            modal.style.display = 'none';
        });

        modal.style.display = 'flex';
    }

    static showAddUserModal(user = null) {
        const modal = document.getElementById('user-modal');
        if (!modal) return;

        const isEditMode = user !== null;
        
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3><i class="fas fa-user-plus"></i> ${isEditMode ? 'Modifier' : 'Ajouter'} Utilisateur</h3>
                    <span class="close">&times;</span>
                </div>
                <form id="user-form">
                    <div class="form-grid">
                        <div class="input-group">
                            <label for="user-username">Nom d'utilisateur*</label>
                            <input type="text" id="user-username" value="${user?.username || ''}" required>
                        </div>
                        <div class="input-group">
                            <label for="user-email">Email*</label>
                            <input type="email" id="user-email" value="${user?.email || ''}" required>
                        </div>
                        <div class="input-group" ${isEditMode ? 'style="display:none;"' : ''}>
                            <label for="user-password">Mot de passe*</label>
                            <input type="password" id="user-password" ${isEditMode ? '' : 'required'}>
                        </div>
                        <div class="input-group">
                            <label for="user-role">Rôle*</label>
                            <select id="user-role" required>
                                <option value="">Sélectionner un rôle</option>
                                <option value="admin" ${user?.role === 'admin' ? 'selected' : ''}>Administrateur</option>
                                <option value="bibliothecaire" ${user?.role === 'bibliothecaire' ? 'selected' : ''}>Bibliothécaire</option>
                                <option value="etudiant" ${user?.role === 'etudiant' ? 'selected' : ''}>Étudiant</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn danger" id="cancel-user-btn">
                            <i class="fas fa-times"></i> Annuler
                        </button>
                        <button type="submit" class="btn primary">
                            <i class="fas fa-save"></i> ${isEditMode ? 'Mettre à jour' : 'Enregistrer'}
                        </button>
                    </div>
                </form>
            </div>
        `;

        document.getElementById('cancel-user-btn')?.addEventListener('click', () => {
            modal.style.display = 'none';
        });

        modal.style.display = 'flex';
    }
}

class App {
    static async init() {
        try {
            await LibraTech.init();
            this.initEventListeners();
            
            const savedUser = sessionStorage.getItem('currentUser');
            if (savedUser) {
                currentUser = JSON.parse(savedUser);
                this.showMainInterface();
                this.loadBooks();
                UI.loadRoleMenu(currentUser.role);
                UI.toggleAdminFeatures();
            }
        } catch (error) {
            UI.showNotification(`Erreur d'initialisation: ${error}`, 'danger');
        }
    }

    static initEventListeners() {
        document.getElementById('login-form')?.addEventListener('submit', async (e) => {
            e.preventDefault();
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value.trim();
            const role = document.getElementById('userType').value;

            try {
                currentUser = await LibraTech.login(username, password, role);
                sessionStorage.setItem('currentUser', JSON.stringify(currentUser));
                this.showMainInterface();
                this.loadBooks();
                UI.loadRoleMenu(role);
                UI.toggleAdminFeatures();
                UI.showNotification('Connexion réussie !', 'success');
            } catch (error) {
                UI.showNotification(error, 'danger');
            }
        });

        document.getElementById('logout-btn')?.addEventListener('click', () => {
            sessionStorage.clear();
            location.reload();
        });

        document.addEventListener('input', async (e) => {
            if (e.target.id === 'searchInput') {
                const results = await LibraTech.searchBooks(e.target.value);
                UI.renderBooks(results);
            }
        });

        document.addEventListener('click', async (e) => {
            if (e.target.closest('[data-filter]')) {
                const filter = e.target.closest('[data-filter]').dataset.filter;
                const livres = filter === 'all' 
                    ? await LibraTech.getLivres() 
                    : await LibraTech.getBooksByStatus(filter);
                UI.renderBooks(livres);
            }
        });

        document.addEventListener('click', async (e) => {
            const bookCard = e.target.closest('.book-card');
            if (bookCard) {
                const livreId = parseInt(bookCard.dataset.id);
                const livre = currentBooks.find(l => l.id === livreId);
                if (livre) LibraTech.showBookDetails(livre);
                return;
            }

            const actionBtn = e.target.closest('[data-action]');
            if (actionBtn) {
                const action = actionBtn.dataset.action;
                const livreId = parseInt(actionBtn.dataset.id);
                
                try {
                    switch (action) {
                        case 'borrow':
                            await LibraTech.emprunterLivre(livreId);
                            UI.showNotification('Livre emprunté avec succès', 'success');
                            break;
                        case 'return':
                            await LibraTech.retournerLivre(livreId);
                            UI.showNotification('Livre retourné avec succès', 'success');
                            break;
                        case 'reserve':
                            await LibraTech.reserverLivre(livreId);
                            UI.showNotification('Livre réservé avec succès', 'success');
                            break;
                        case 'cancel-reserve':
                            await LibraTech.annulerReservation(livreId);
                            UI.showNotification('Réservation annulée', 'warning');
                            break;
                        case 'edit':
                            await this.editerLivre(livreId);
                            return;
                        case 'delete':
                            await this.supprimerLivre(livreId);
                            break;
                    }
                    
                    this.loadBooks();
                    document.getElementById('book-details-modal').style.display = 'none';
                } catch (error) {
                    UI.showNotification(error.message || 'Erreur lors de l\'opération', 'danger');
                }
            }
        });

        document.addEventListener('click', (e) => {
            if (e.target.id === 'manage-users-btn' || 
                e.target.closest('[data-action="gestion-utilisateurs"]')) {
                this.showUserManagement();
            }

            if (e.target.id === 'add-user-btn' || 
                e.target.closest('[data-action="ajouter-utilisateur"]')) {
                UI.showAddUserModal();
            }

            const userActionBtn = e.target.closest('[data-user-id]');
            if (userActionBtn) {
                const action = userActionBtn.dataset.action;
                const userId = parseInt(userActionBtn.dataset.userId);
                
                if (action === 'edit') this.editerUtilisateur(userId);
                if (action === 'delete') this.supprimerUtilisateur(userId);
            }
        });

        document.addEventListener('click', (e) => {
            if (e.target.id === 'scan-isbn-btn' || e.target.closest('#scan-isbn-btn') ||
                e.target.id === 'scanner-btn' || e.target.closest('#scanner-btn')) {
                this.initScanner();
            }
            if (e.target.id === 'close-scanner' || e.target.closest('#close-scanner')) {
                this.closeScanner();
            }
        });

        document.addEventListener('click', (e) => {
            if (e.target.id === 'add-book-btn' || 
                e.target.closest('[data-action="ajouter-livre"]')) {
                UI.showAddBookModal();
            }
        });

        document.addEventListener('submit', async (e) => {
            if (e.target.id === 'book-form') {
                e.preventDefault();
                const livreId = e.target.querySelector('[data-id]')?.dataset.id;
                if (livreId) {
                    await this.updateBook(parseInt(livreId));
                } else {
                    await this.addNewBook();
                }
            }

            if (e.target.id === 'user-form') {
                e.preventDefault();
                const userId = e.target.querySelector('[data-user-id]')?.dataset.userId;
                if (userId) {
                    await this.updateUser(parseInt(userId));
                } else {
                    await this.addNewUser();
                }
            }
        });

        document.addEventListener('click', (e) => {
            if (e.target.closest('[data-action="historique-reservations"]')) {
                this.showReservationsHistory();
            }
        });

        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('close')) {
                document.querySelectorAll('.modal').forEach(modal => {
                    modal.style.display = 'none';
                });
            }
        });
    }

    static async loadBooks() {
        try {
            const livres = await LibraTech.getLivres();
            UI.renderBooks(livres);
            UI.updateStats(livres);
        } catch (error) {
            console.error("Erreur de chargement des livres:", error);
            UI.showNotification('Erreur de chargement des livres', 'danger');
        }
    }

    static showMainInterface() {
        document.getElementById('login-container')?.classList.add('hidden');
        document.getElementById('app-container')?.classList.remove('hidden');
        document.getElementById('role-display').textContent = currentUser.role.toUpperCase();
    }

    static async addNewBook() {
        try {
            const elements = {
                title: document.getElementById('book-title'),
                isbn: document.getElementById('book-isbn'),
                cover: document.getElementById('book-cover'),
                form: document.getElementById('book-form')
            };
    
            // Réinitialisation des erreurs
            document.querySelectorAll('.error-message').forEach(el => el.textContent = '');
    
            // Validation synchrone
            if (!elements.title.value.trim() || !elements.isbn.value.trim()) {
                throw new Error('Champs requis manquants');
            }
    
            // Conversion de l'image
            let couverture = '';
            if (elements.cover.files[0]) {
                couverture = await this.readFileAsDataURL(elements.cover.files[0]);
            }
    
            // Création de l'objet livre
            const nouveauLivre = {
                titre: elements.title.value.trim(),
                isbn: elements.isbn.value.trim(),
                couverture,
                statut: 'Disponible',
                dateAjout: new Date().toISOString()
            };
    
            // Ajout avec vérification d'unicité
            await LibraTech.addLivre(nouveauLivre);
            
            elements.form.reset();
            this.loadBooks();
            UI.showNotification('Ajout réussi', 'success');
    
        } catch (error) {
            this.handleAddError(error);
        }
    }
    
    static handleAddError(error) {
        const errorMapping = {
            'ISBN existe déjà': () => {
                document.getElementById('isbn-error').textContent = error.message;
            },
            'Champs requis manquants': () => {
                if (!document.getElementById('book-title').value) {
                    document.getElementById('title-error').textContent = 'Ce champ est requis';
                }
                if (!document.getElementById('book-isbn').value) {
                    document.getElementById('isbn-error').textContent = 'Ce champ est requis';
                }
            }
        };
    
        errorMapping[error.message]?.() || UI.showNotification(error.message, 'danger');
    }

    static async updateBook(id) {
        const titre = document.getElementById('book-title').value;
        const auteur = document.getElementById('book-author').value;
        const isbn = document.getElementById('book-isbn').value;
        const genre = document.getElementById('book-genre').value;
        const description = document.getElementById('book-description').value;
        const coverFile = document.getElementById('book-cover').files[0];

        if (!titre || !auteur || !isbn) {
            UI.showNotification('Veuillez remplir tous les champs obligatoires', 'danger');
            return;
        }

        try {
            const livre = await LibraTech.getLivreById(id);
            if (!livre) {
                throw new Error('Livre non trouvé');
            }

            livre.titre = titre;
            livre.auteur = auteur;
            livre.isbn = isbn;
            livre.genre = genre;
            livre.description = description;

            if (coverFile) {
                livre.couverture = await this.readFileAsDataURL(coverFile);
            }

            await LibraTech.updateLivre(livre);
            document.getElementById('book-modal').style.display = 'none';
            this.loadBooks();
            UI.showNotification('Livre mis à jour avec succès', 'success');
        } catch (error) {
            console.error("Erreur lors de la mise à jour du livre:", error);
            UI.showNotification('Erreur lors de la mise à jour: ' + error.message, 'danger');
        }
    }

    static async editerLivre(id) {
        try {
            const livre = await LibraTech.getLivreById(id);
            if (!livre) {
                throw new Error('Livre non trouvé');
            }

            UI.showAddBookModal(livre);
            const submitBtn = document.querySelector('#book-form button[type="submit"]');
            submitBtn.setAttribute('data-id', id);
        } catch (error) {
            console.error("Erreur lors de l'édition du livre:", error);
            UI.showNotification('Erreur lors de l\'édition du livre: ' + error.message, 'danger');
        }
    }

    static async supprimerLivre(id) {
        if (!confirm('Confirmer la suppression de ce livre ?')) return;
        
        try {
            const reservations = await LibraTech.getReservationsByBook(id);
            for (const res of reservations) {
                await LibraTech.deleteReservation(res.id);
            }
            
            await LibraTech.deleteLivre(id);
            
            this.loadBooks();
            UI.showNotification('Livre supprimé avec succès', 'warning');
        } catch (error) {
            console.error("Erreur lors de la suppression du livre:", error);
            UI.showNotification('Erreur lors de la suppression du livre: ' + error.message, 'danger');
        }
    }

    static async addNewUser() {
        const username = document.getElementById('user-username').value;
        const email = document.getElementById('user-email').value;
        const password = document.getElementById('user-password').value;
        const role = document.getElementById('user-role').value;

        if (!username || !email || !role || (!password && !document.getElementById('user-password').hasAttribute('data-skip'))) {
            UI.showNotification('Veuillez remplir tous les champs obligatoires', 'danger');
            return;
        }

        try {
            await LibraTech.addUser({
                username,
                email,
                password: password || 'defaultPassword',
                role,
                dateCreation: new Date().toISOString()
            });

            document.getElementById('user-form').reset();
            document.getElementById('user-modal').style.display = 'none';
            this.showUserManagement();
            UI.showNotification('Utilisateur ajouté avec succès', 'success');
        } catch (error) {
            console.error("Erreur lors de l'ajout de l'utilisateur:", error);
            UI.showNotification('Erreur lors de l\'ajout: ' + error.message, 'danger');
        }
    }

    static async updateUser(id) {
        const username = document.getElementById('user-username').value;
        const email = document.getElementById('user-email').value;
        const role = document.getElementById('user-role').value;

        if (!username || !email || !role) {
            UI.showNotification('Veuillez remplir tous les champs obligatoires', 'danger');
            return;
        }

        try {
            const users = await LibraTech.getUtilisateurs();
            const user = users.find(u => u.id === id);
            if (!user) {
                throw new Error('Utilisateur non trouvé');
            }

            user.username = username;
            user.email = email;
            user.role = role;

            await LibraTech.updateUser(user);
            document.getElementById('user-modal').style.display = 'none';
            this.showUserManagement();
            UI.showNotification('Utilisateur mis à jour', 'success');
        } catch (error) {
            console.error("Erreur lors de la mise à jour de l'utilisateur:", error);
            UI.showNotification('Erreur de mise à jour: ' + error.message, 'danger');
        }
    }

    static async editerUtilisateur(id) {
        try {
            const users = await LibraTech.getUtilisateurs();
            const user = users.find(u => u.id === id);
            if (!user) {
                throw new Error('Utilisateur non trouvé');
            }

            UI.showAddUserModal(user);
            const submitBtn = document.querySelector('#user-form button[type="submit"]');
            submitBtn.setAttribute('data-user-id', id);
            document.getElementById('user-password').setAttribute('data-skip', 'true');
        } catch (error) {
            console.error("Erreur lors de l'édition de l'utilisateur:", error);
            UI.showNotification('Erreur lors de l\'édition: ' + error.message, 'danger');
        }
    }

    static async supprimerUtilisateur(id) {
        if (id === 1) {
            UI.showNotification('Impossible de supprimer l\'administrateur principal', 'danger');
            return;
        }
        
        if (!confirm('Confirmer la suppression de cet utilisateur ?')) return;
        
        try {
            await LibraTech.deleteUser(id);
            this.showUserManagement();
            UI.showNotification('Utilisateur supprimé avec succès', 'warning');
        } catch (error) {
            console.error("Erreur lors de la suppression de l'utilisateur:", error);
            UI.showNotification('Erreur de suppression: ' + error.message, 'danger');
        }
    }

    static async showUserManagement() {
        try {
            const users = await LibraTech.getUtilisateurs();
            UI.renderUsers(users);
        } catch (error) {
            console.error("Erreur lors du chargement des utilisateurs:", error);
            UI.showNotification('Erreur lors du chargement des utilisateurs', 'danger');
        }
    }

    static async showReservationsHistory() {
        try {
            let reservations = await LibraTech.getReservations();
            
            const livres = await LibraTech.getLivres();
            const users = await LibraTech.getUtilisateurs();
            
            reservations = reservations.map(res => {
                const livre = livres.find(l => l.id === res.livreId);
                const user = users.find(u => u.id === res.userId);
                return {
                    ...res,
                    livreTitre: livre?.titre,
                    livreAuteur: livre?.auteur,
                    userName: user?.username,
                    userEmail: user?.email
                };
            }).sort((a, b) => 
                new Date(b.dateEmprunt || b.dateReservation) - 
                new Date(a.dateEmprunt || a.dateReservation)
            );
            
            LibraTech.showReservations(reservations);
        } catch (error) {
            console.error("Erreur lors du chargement des réservations:", error);
            UI.showNotification('Erreur lors du chargement de l\'historique', 'danger');
        }
    }

    static readFileAsDataURL(file) {
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onload = (e) => resolve(e.target.result);
            reader.readAsDataURL(file);
        });
    }

    static initScanner() {
        if (!window.ZXing) {
            UI.showNotification('Scanner non disponible', 'danger');
            return;
        }
    
        scanner = new ZXing.BrowserQRCodeReader();
        const video = document.getElementById('scanner-video');
        
        scanner.decodeFromVideoDevice(null, video, (result, error) => {
            if (result) {
                try {
                    const livreData = JSON.parse(result.text);
                    const livre = currentBooks.find(l => l.id === livreData.id);
                    if (livre) {
                        LibraTech.showBookDetails(livre);
                    }
                } catch (e) {
                    UI.showNotification('QR code invalide', 'danger');
                }
                scanner.reset();
                document.getElementById('scanner-modal').style.display = 'none';
            }
        });
    }

    static closeScanner() {
        if (scanner) {
            scanner.reset();
            scanner = null;
        }
        document.getElementById('scanner-modal').style.display = 'none';
    }
}
document.addEventListener('click', async (e) => {
    // Gestion du clic sur une carte de livre
    const bookCard = e.target.closest('.book-card');
    if (bookCard) {
        const livreId = parseInt(bookCard.dataset.id);
        const livre = currentBooks.find(l => l.id === livreId);
        if (livre) {
            LibraTech.showBookDetails(livre);
        }
        return;
    }

    // Gestion des boutons d'action
    const actionBtn = e.target.closest('[data-action]');
    if (actionBtn) {
        const action = actionBtn.dataset.action;
        const livreId = parseInt(actionBtn.dataset.id);
        
        try {
            switch (action) {
                case 'borrow':
                    await LibraTech.emprunterLivre(livreId);
                    UI.showNotification('Livre emprunté avec succès', 'success');
                    break;
                case 'return':
                    await LibraTech.retournerLivre(livreId);
                    UI.showNotification('Livre retourné avec succès', 'success');
                    break;
                case 'reserve':
                    await LibraTech.reserverLivre(livreId);
                    UI.showNotification('Livre réservé avec succès', 'success');
                    break;
                case 'cancel-reserve':
                    await LibraTech.annulerReservation(livreId);
                    UI.showNotification('Réservation annulée', 'warning');
                    break;
                case 'edit':
                    // Fermer le modal des détails avant d'ouvrir l'édition
                    document.getElementById('book-details-modal').style.display = 'none';
                    await this.editerLivre(livreId);
                    return;
                case 'delete':
                    await this.supprimerLivre(livreId);
                    break;
            }
            
            // Recharger les livres et fermer les modals
            this.loadBooks();
            document.getElementById('book-details-modal').style.display = 'none';
        } catch (error) {
            UI.showNotification(error.message || 'Erreur lors de l\'opération', 'danger');
        }
    }

    // Gestion des autres éléments
    if (e.target.id === 'manage-users-btn' || 
        e.target.closest('[data-action="gestion-utilisateurs"]')) {
        this.showUserManagement();
    }

    if (e.target.id === 'add-user-btn' || 
        e.target.closest('[data-action="ajouter-utilisateur"]')) {
        UI.showAddUserModal();
    }

    const userActionBtn = e.target.closest('[data-user-id]');
    if (userActionBtn) {
        const action = userActionBtn.dataset.action;
        const userId = parseInt(userActionBtn.dataset.userId);
        
        if (action === 'edit') this.editerUtilisateur(userId);
        if (action === 'delete') this.supprimerUtilisateur(userId);
    }

    if (e.target.id === 'scan-isbn-btn' || e.target.closest('#scan-isbn-btn') ||
        e.target.id === 'scanner-btn' || e.target.closest('#scanner-btn')) {
        this.initScanner();
    }
    if (e.target.id === 'close-scanner' || e.target.closest('#close-scanner')) {
        this.closeScanner();
    }

    if (e.target.id === 'add-book-btn' || 
        e.target.closest('[data-action="ajouter-livre"]')) {
        UI.showAddBookModal();
    }

    if (e.target.closest('[data-action="historique-reservations"]')) {
        this.showReservationsHistory();
    }

    if (e.target.classList.contains('close')) {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.style.display = 'none';
        });
    }
});
// Gestion du filtrage
document.getElementById('filter-menu').addEventListener('click', async (e) => {
    const filterBtn = e.target.closest('[data-filter]');
    if (filterBtn) {
        const filter = filterBtn.dataset.filter;
        try {
            const livres = filter === 'all' 
                ? await LibraTech.getLivres()
                : await LibraTech.getBooksByStatus(filter);
            
            UI.renderBooks(livres);
            document.getElementById('filter-menu').classList.remove('show');
        } catch (error) {
            UI.showNotification(`Erreur de filtrage: ${error.message}`, 'danger');
        }
    }
});

document.addEventListener('DOMContentLoaded', () => App.init());
