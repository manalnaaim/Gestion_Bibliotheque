// indexeddb.js

let db;
const request = indexedDB.open("LibraTechDB", 1);

request.onerror = function (event) {
    console.error("Erreur d'ouverture de la base IndexedDB", event);
};

request.onupgradeneeded = function (event) {
    db = event.target.result;
    
    // Crée les object stores s'ils n'existent pas
    if (!db.objectStoreNames.contains("livres")) {
        db.createObjectStore("livres", { keyPath: "id" });
    }

    if (!db.objectStoreNames.contains("reservations")) {
        db.createObjectStore("reservations", { keyPath: "id", autoIncrement: true });
    }

    // Tu peux ajouter d'autres stores ici
};

request.onsuccess = function (event) {
    db = event.target.result;
    console.log("Base de données IndexedDB ouverte avec succès.");
};
// main.js

function reserverLivre(livreId) {
    const transaction = db.transaction(["reservations"], "readwrite");
    const store = transaction.objectStore("reservations");
    
    const nouvelleReservation = {
        livreId: livreId,
        date: new Date(),
        statut: "ACTIVE"
    };

    store.add(nouvelleReservation);
}
