from django.db import models
from django.contrib.auth.models import AbstractUser

class Utilisateur(AbstractUser):
    ROLES = (
        ('ADMIN', 'Administrateur'),
        ('BIBLIO', 'Bibliothécaire'),
        ('ETUDIANT', 'Étudiant'),
    )
    role = models.CharField(max_length=10, choices=ROLES, default='ETUDIANT')
    email = models.EmailField(unique=True)
    
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']

class Livre(models.Model):
    STATUTS = (
        ('DISPONIBLE', 'Disponible'),
        ('EMPRUNTE', 'Emprunté'),
        ('RESERVE', 'Réservé'),
    )
    titre = models.CharField(max_length=200)
    auteur = models.CharField(max_length=100)
    isbn = models.CharField(max_length=20, unique=True)
    couverture = models.ImageField(upload_to='couvertures/', null=True, blank=True)
    description = models.TextField(blank=True)
    statut = models.CharField(max_length=10, choices=STATUTS, default='DISPONIBLE')
    date_ajout = models.DateTimeField(auto_now_add=True)

class Reservation(models.Model):
    STATUTS = (
        ('ACTIVE', 'Active'),
        ('TERMINEE', 'Terminée'),
        ('ANNULEE', 'Annulée'),
    )
    livre = models.ForeignKey(Livre, on_delete=models.CASCADE)
    utilisateur = models.ForeignKey(Utilisateur, on_delete=models.CASCADE)
    date_reservation = models.DateTimeField(auto_now_add=True)
    date_emprunt = models.DateTimeField(null=True, blank=True)
    date_retour = models.DateTimeField(null=True, blank=True)
    statut = models.CharField(max_length=10, choices=STATUTS, default='ACTIVE')
# views.py
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

@csrf_exempt  # Temporaire, à remplacer par une authentification appropriée
def livres_api(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            # Créer un nouveau livre dans la base Django
            livre = Livre.objects.create(
                titre=data['titre'],
                auteur=data['auteur'],
                isbn=data['isbn'],
                statut='Disponible'
            )
            return JsonResponse({'id': livre.id, 'status': 'success'})
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)
    
    elif request.method == 'GET':
        livres = list(Livre.objects.values())
        return JsonResponse(livres, safe=False)

@csrf_exempt
def livre_detail_api(request, id):
    try:
        livre = Livre.objects.get(pk=id)
        if request.method == 'DELETE':
            livre.delete()
            return JsonResponse({'status': 'deleted'})
        # Autres méthodes...
    except Livre.DoesNotExist:
        return JsonResponse({'error': 'Livre non trouvé'}, status=404)