from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from django.views.generic import TemplateView
from bibliotheque import views

urlpatterns = [
    # Pages HTML
    path('', TemplateView.as_view(template_name='login.html'), name='login'),
    path('admin/', admin.site.urls),
    path('admin.html', TemplateView.as_view(template_name='admin.html'), name='admin_custom'),
    path('bibliothecaire/', TemplateView.as_view(template_name='bibliothecaire.html'), name='bibliothecaire'),

    # API
    path('api/livres/', views.livres_api, name='api_livres'),
    path('api/livres/<int:id>/', views.livre_detail_api, name='api_livre_detail'),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from django.views.generic import TemplateView
from bibliotheque import views

urlpatterns = [
    # Routes API
    path('api/livres/', views.livres_api, name='api_livres'),
    path('api/livres/<int:id>/', views.livre_detail_api, name='api_livre_detail'),

    # Routes templates
    path('', TemplateView.as_view(template_name='login.html'), name='login'),
    path('admin/', admin.site.urls),
    path('admin.html', TemplateView.as_view(template_name='admin.html'), name='admin_custom'),
    path('bibliothecaire/', TemplateView.as_view(template_name='bibliothecaire.html'), name='bibliothecaire'),
    path('login.html', TemplateView.as_view(template_name='login.html')),
    path('bibliothecaire.html', TemplateView.as_view(template_name='bibliothecaire.html')),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
path('redirect/', views.custom_redirect, name='custom_redirect'),

from django.http import JsonResponse
from bibliotheque.models import Livre  # Votre modèle

def livres_api(request):
    livres = list(Livre.objects.values())  # Convertit en liste de dictionnaires
    return JsonResponse({"livres": livres}, safe=False)

