from rest_framework import serializers
from bibliotheque.models import Livre, Reservation, Utilisateur

class LivreSerializer(serializers.ModelSerializer):
    class Meta:
        model = Livre
        fields = '__all__'

class ReservationSerializer(serializers.ModelSerializer):
    livre = LivreSerializer(read_only=True)
    
    class Meta:
        model = Reservation
        fields = '__all__'

class UtilisateurSerializer(serializers.ModelSerializer):
    class Meta:
        model = Utilisateur
        fields = ['id', 'username', 'email', 'role']