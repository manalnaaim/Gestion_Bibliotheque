from rest_framework import viewsets, permissions, status
from rest_framework.response import Response
from .models import Livre, Reservation, Utilisateur
from .serializer import LivreSerializer, ReservationSerializer, UtilisateurSerializer
from django.utils import timezone
from datetime import timedelta

class LivreViewSet(viewsets.ModelViewSet):
    queryset = Livre.objects.all()
    serializer_class = LivreSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

class ReservationViewSet(viewsets.ModelViewSet):
    queryset = Reservation.objects.all()
    serializer_class = ReservationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def create(self, request, *args, **kwargs):
        livre_id = request.data.get('livre')
        livre = Livre.objects.get(id=livre_id)
        
        if livre.statut != 'DISPONIBLE':
            return Response(
                {'error': 'Livre non disponible'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
            
        livre.statut = 'RESERVE'
        livre.save()
        
        reservation = Reservation.objects.create(
            livre=livre,
            utilisateur=request.user,
            date_emprunt=timezone.now(),
            date_retour=timezone.now() + timedelta(days=14)
        )
        
        serializer = self.get_serializer(reservation)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

class UtilisateurViewSet(viewsets.ModelViewSet):
    queryset = Utilisateur.objects.all()
    serializer_class = UtilisateurSerializer
    permission_classes = [permissions.IsAdminUser]

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Livre
import json

@csrf_exempt
def livres_api(request):
    if request.method == 'GET':
        livres = list(Livre.objects.values())
        return JsonResponse(livres, safe=False)
        
    elif request.method == 'POST':
        try:
            data = json.loads(request.body)
            livre = Livre.objects.create(
                titre=data['titre'],
                auteur=data['auteur'],
                isbn=data['isbn'],
                statut=data.get('statut', 'Disponible')
            )
            return JsonResponse({'id': livre.id, 'status': 'success'})
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)

@csrf_exempt
def livre_detail_api(request, id):
    try:
        livre = Livre.objects.get(pk=id)
        
        if request.method == 'GET':
            return JsonResponse({
                'id': livre.id,
                'titre': livre.titre,
                'auteur': livre.auteur,
                'isbn': livre.isbn,
                'statut': livre.statut
            })
            
        elif request.method == 'PUT':
            data = json.loads(request.body)
            for field, value in data.items():
                setattr(livre, field, value)
            livre.save()
            return JsonResponse({'status': 'updated'})
            
        elif request.method == 'DELETE':
            livre.delete()
            return JsonResponse({'status': 'deleted'})
            
    except Livre.DoesNotExist:
        return JsonResponse({'error': 'Livre non trouvé'}, status=404)

# Ajoutez les autres vues nécessaires ici...from django.http import JsonResponse
from .models import Livre

def livres_api(request):
    livres = list(Livre.objects.values())
    return JsonResponse(livres, safe=False)

def livre_detail_api(request, id):
    try:
        livre = Livre.objects.get(id=id)
        return JsonResponse({'titre': livre.titre, 'auteur': livre.auteur})
    except Livre.DoesNotExist:
        return JsonResponse({'error': 'Livre non trouvé'}, status=404)
from django.shortcuts import redirect
from django.contrib.auth.decorators import login_required

@login_required
def custom_redirect(request):
    if request.user.is_staff:  # Si l'utilisateur est un administrateur
        return redirect('/admin/')  # Redirige vers l'interface d'administration Django
    return redirect('admin_custom')  # Sinon, redirige vers admin.html
from django.shortcuts import redirect
from django.contrib.auth.decorators import login_required

@login_required
def custom_redirect(request):
    if request.user.is_staff:
        return redirect('/admin/')
    return redirect('admin_custom')
from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from django.contrib import messages

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            if user.role == 'admin':
                return redirect('admin_custom')  # Rediriger vers la page d'admin
            elif user.role == 'bibliothecaire':
                return redirect('bibliothecaire')  # Rediriger vers la page bibliothécaire
            else:
                messages.error(request, 'Rôle inconnu.')
        else:
            messages.error(request, 'Identifiants incorrects.')
    return render(request, 'login.html')
# views.py
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Livre

@csrf_exempt
def api_livres(request):
    if request.method == 'GET':
        livres = Livre.objects.all().values('id', 'titre', 'auteur', 'statut', 'couverture')
        return JsonResponse(list(livres), safe=False)

@csrf_exempt
def emprunter_livre(request, livre_id):
    if request.method == 'POST':
        # Implémentez la logique d'emprunt
        return JsonResponse({'status': 'success'})
    
from django.http import JsonResponse
from .models import Livre  # Votre modèle

def livres_api(request):
    livres = list(Livre.objects.values())  # Convertit en liste de dictionnaires
    return JsonResponse({"livres": livres}, safe=False)   
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Livre  # Importez votre modèle

@csrf_exempt  # Désactive la protection CSRF pour simplifier
def livre_list(request):
    if request.method == 'GET':
        livres = list(Livre.objects.values('id', 'titre'))  # Récupère seulement id et titre
        return JsonResponse({'livres': livres})
    
    elif request.method == 'POST':
        Livre.objects.create(
            titre=request.POST.get('titre'),
            auteur=request.POST.get('auteur')
        )
        return JsonResponse({'status': 'ok'}, status=201)