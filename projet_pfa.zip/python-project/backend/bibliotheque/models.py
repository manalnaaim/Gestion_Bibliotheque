from django.db import models
from django.contrib.auth.models import AbstractUser, Group, Permission

# Modèle utilisateur personnalisé
class Utilisateur(AbstractUser):
    ROLES = (
        ('ADMIN', 'Administrateur'),
        ('BIBLIO', 'Bibliothécaire'),
        ('ETUDIANT', 'Étudiant'),
    )
    role = models.CharField(max_length=10, choices=ROLES, default='ETUDIANT')
    email = models.EmailField(unique=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']  # Pour rester compatible avec Django

    # Ajout des related_name pour éviter les conflits
    groups = models.ManyToManyField(
        Group,
        related_name='utilisateur_groups',
        blank=True,
    )
    user_permissions = models.ManyToManyField(
        Permission,
        related_name='utilisateur_permissions',
        blank=True,
    )

    def __str__(self):
        return f"{self.username} ({self.role})"


# Modèle catégorie
class Categorie(models.Model):
    nom = models.CharField(max_length=100)

    def __str__(self):
        return self.nom


# Modèle livre
class Livre(models.Model):
    STATUTS = (
        ('DISPONIBLE', 'Disponible'),
        ('EMPRUNTE', 'Emprunté'),
        ('RESERVE', 'Réservé'),
    )
    titre = models.CharField(max_length=200)
    auteur = models.CharField(max_length=100)
    isbn = models.CharField(max_length=20, unique=True)
    couverture = models.ImageField(upload_to='couvertures/', null=True, blank=True)
    description = models.TextField(blank=True)
    statut = models.CharField(max_length=10, choices=STATUTS, default='DISPONIBLE')
    date_ajout = models.DateTimeField(auto_now_add=True)
    categorie = models.ForeignKey(Categorie, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return self.titre


# Modèle réservation
class Reservation(models.Model):
    STATUTS = (
        ('ACTIVE', 'Active'),
        ('TERMINEE', 'Terminée'),
        ('ANNULEE', 'Annulée'),
    )
    livre = models.ForeignKey(Livre, on_delete=models.CASCADE)
    utilisateur = models.ForeignKey(Utilisateur, on_delete=models.CASCADE)
    date_reservation = models.DateTimeField(auto_now_add=True)
    date_emprunt = models.DateTimeField(null=True, blank=True)
    date_retour = models.DateTimeField(null=True, blank=True)
    statut = models.CharField(max_length=10, choices=STATUTS, default='ACTIVE')
