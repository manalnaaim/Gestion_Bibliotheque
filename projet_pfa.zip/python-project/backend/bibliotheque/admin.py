from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import Livre

from django.contrib import admin
from .models import Utilisateur, Livre, Reservation
from django.contrib.auth.admin import UserAdmin

@admin.register(Utilisateur)
class UtilisateurAdmin(UserAdmin):
    model = Utilisateur
    list_display = ('email', 'username', 'role', 'is_staff', 'is_active')
    list_filter = ('role', 'is_staff', 'is_active')
    fieldsets = (
        (None, {'fields': ('username', 'email', 'password', 'role')}),
        ('Permissions', {'fields': ('is_staff', 'is_active', 'is_superuser', 'groups', 'user_permissions')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'username', 'password1', 'password2', 'role', 'is_staff', 'is_active')}
        ),
    )
    search_fields = ('email', 'username')
    ordering = ('email',)

@admin.register(Livre)
class LivreAdmin(admin.ModelAdmin):
    list_display = ('titre', 'auteur', 'isbn', 'statut', 'date_ajout')
    search_fields = ('titre', 'auteur', 'isbn')
    list_filter = ('statut',)

@admin.register(Reservation)
class ReservationAdmin(admin.ModelAdmin):
    list_display = ('livre', 'utilisateur', 'date_reservation', 'statut')
    list_filter = ('statut', 'date_reservation')
    search_fields = ('livre__titre', 'utilisateur__email')

